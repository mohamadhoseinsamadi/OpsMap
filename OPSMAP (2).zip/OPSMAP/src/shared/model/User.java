package shared.model;

import java.io.Serializable;

public class User implements Serializable {
    private String username;
    private String role;
    private String password; // فقط برای انتقال موقت، ذخیره نمی‌شود

    public User(String username, String role, String password) {
        this.username = username;
        this.role = role;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    public String getPassword() {
        return password;
    }
}
